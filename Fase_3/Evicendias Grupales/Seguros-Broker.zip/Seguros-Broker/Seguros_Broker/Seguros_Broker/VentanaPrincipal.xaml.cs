﻿using Seguros_Broker.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Seguros_Broker
{

    public partial class VentanaPrincipal
    {
        private PropuestaRep propuestaRep = new PropuestaRep();

        public VentanaPrincipal()
        {
            InitializeComponent();
            MainContent.Content = new UserControlTablaPropuestas();
        }

        private void Ejecutivo_Click(object sender, RoutedEventArgs e)
        {
            var VentanaEjecutivo = new Ejecutivo();
            VentanaEjecutivo.ShowDialog();
        }
        private void Socio_Click(object sender, RoutedEventArgs e)
        {
            var VentanaSocio = new SocioMantenedor();
            VentanaSocio.ShowDialog();
        }       

        private void NuevaPropuesta_Click(object sender, RoutedEventArgs e)
        {
            var NuevaPropuestaCaratula = new NuevaPropuestaCaratula();
            NuevaPropuestaCaratula.ShowDialog();
        }

        private void Compania_Click(object sender, RoutedEventArgs e)
        {
            var CompaniaMantenedor = new CompaniaMantenedor();
            CompaniaMantenedor.ShowDialog();
        }

        private void Moneda_Click(object sender, RoutedEventArgs e)
        {
            var VentanaMoneda = new MonedaMantedor();
            VentanaMoneda.ShowDialog();

        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Cliente_Click(object sender, RoutedEventArgs e)
        {
            var ClienteMantenedor = new ClienteMantenedor();
            ClienteMantenedor.ShowDialog();
        }

        private void Producto_Click(object sender, RoutedEventArgs e)
        {
            var ProductoMantendor = new ProductoMantenedor();
            ProductoMantendor.ShowDialog();
        }
        private void BuscarPropuesta_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MainContent.Content = new UserControlBuscarPropuesta();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void MainRibbon_SelectedTabChanged(object sender, RoutedEventArgs e)
        {
            var selected = MainRibbon.SelectedTabItem;

            if (selected == Maestros_RibbonTabItem)
            {
                MainContent.Content = new UserControlTablaPropuestas();
            }
        }
    }
    
}
