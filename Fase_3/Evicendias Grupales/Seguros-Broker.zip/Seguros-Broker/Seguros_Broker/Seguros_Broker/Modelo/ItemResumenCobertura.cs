﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seguros_Broker.Modelo
{
    public class ItemResumenCobertura
    {

        public int Numero { get; set; }

        public decimal PrimaNeta { get; set; }
    }
}