﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seguros_Broker.Modelo
{
    public class Moneda
    {
        public int monedaId { get; set; }

        public string nombre { get; set; } = "";

        public string simbolo { get; set; } = "";


    }
}
